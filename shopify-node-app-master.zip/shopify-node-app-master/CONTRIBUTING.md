# How to contribute

The goal of this project is to provide an example app that demonstrates `@shopify/polaris` and `@shopify/express`. The best way to contribute is to open an issue about anything that you would like to learn more about.
